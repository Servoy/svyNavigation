/* A simple button. It can contain text as well as (optionally) an icon before or after the text. */

/**
* Set the focus to this button.
* 
* @example %%prefix%%%%elementName%%.requestFocus();
*/
function requestFocus() {}