/**
 * Adds the given slide
 * 
 * @param {slide} slideToAdd
 */
function addSlide(slideToAdd) {
}

/**
 * Sets the given slides
 * 
 * @param {Array<slide>} slides
 */
function setSlides(slides) {
}

/**
 * Removes the slide at the given index (0 based)
 * 
 * @param {Number} index
 */
function removeSlide(index) {
}

/**
 * Returns the index of the currently selected slide (0 based)
 * 
 * @return {Number} index
 */
function getSelectedIndex() {
}

/**
 * Sets the selected slide to the given index (0 based)
 * 
 * @param {Number} index
 */
function setSelectedIndex(index) {
}