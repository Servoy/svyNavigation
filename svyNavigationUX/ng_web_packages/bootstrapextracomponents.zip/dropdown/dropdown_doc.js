/**
 * Sets the menu items of the Dropdown
 * 
 * @param {bootstrapextracomponents-dropdown.MenuItem[]} menuItems
 */
function setMenuItems(menuItems) {
}

/**
 * Adds the given menu item to the Dropdown
 * 
 * @param {bootstrapextracomponents-dropdown.MenuItem} menuItem
 */
function addMenuItem(menuItem) {
}

/**
 * Removes the menu item with the given item ID
 * 
 * @param {String} menuItemId
 */
function removeMenuItem(menuItemId) {
}

