/**
 * Selects the tab of the given index
 */
function selectTabAt(idx) {}

/**
 * Adds a tab with the given form and tab text on the given index.
 */
 function addTab(form, tabText, index) {}

/**
 * Removes the tab from the given index.
 */
function removeTabAt(index) {}

/**
 * Removes all tabs of this tabpanel
 */
function removeAllTabs() {}